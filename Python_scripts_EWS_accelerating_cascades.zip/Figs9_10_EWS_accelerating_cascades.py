# -*- coding: utf-8 -*-
"""
Created on Wed May  7 11:48:05 2025

@author: Paul Ritchie

Script to plot ROC curves and AUC colour plot - Figures 9 & 10 in 'Early warning
skill, extrapolation and tipping for accelerating cascades'
"""

import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.optimize import least_squares
import scipy.io as sp
from matplotlib import rc
import matplotlib.colors as colors

def truncate_colormap(cmap, minval=0.0, maxval=1.0, n=100):
    new_cmap = colors.LinearSegmentedColormap.from_list(
        'trunc({n},{a:.2f},{b:.2f})'.format(n=cmap.name, a=minval, b=maxval),
        cmap(np.linspace(minval, maxval, n)))
    return new_cmap

def fun(x,t,decay_rate):
    """
    Function for applying a linear fit to the square of the decay rate using
    least squares.
    
    Parameters
    ----------
    x : Array of float64
        Coefficients of linear fit
    t : Array of float64
        Dummy variable
    decay_rate : Array of float64
        Square of decay rate that linear fit is applied to

    Returns
    -------
    residual : Array of float64
          Residual between linear fit and square of decay rate

    """
    
    residual = np.array(x[0]+x[1]*t-decay_rate)
    
    return residual

def integrate(x, y):
    """
    Apply trapezoidal rule to integrate y with respect to x    
    Parameters
    ----------
    x : Array of float64
    y : Array of float64

    Returns
    -------
    sm : float64
          Integral of y with respect to x

    """
    sm = 0
    for i in range(1, len(x)):
        # Step spacing
        h = x[i] - x[i-1]
        # Trapezoidal rule
        sm += h * (y[i-1] + y[i]) / 2
 
    return sm

def f(x, forcing):
    """
    Generic double fold bifurcation model used for both upstream and downstream
    systems.

    Parameters
    ----------
    x : float64
        State variable for upstream or downstream system.
    forcing : float64
        External forcing to drive the system.

    Returns
    -------
    f : float64
        RHS of ODE.

    """  
    f = 3*x - x**3 + forcing    
    return (f)

def forcing_ramp(t, lamb_min, lamb_max, r):
    """
    Tanh ramp forcing for upstream system.

    Parameters
    ----------
    t : float64
        Time
    lamb_min : float64
        Initial level of forcing.
    lamb_max : float64
        Final level of forcing.
    r : float64
        Rate parameter of ramp.

    Returns
    -------
    lamb : float64
        Upstream ramp forcing profile.

    """
    lamb = lamb_min + (lamb_max-lamb_min)*(np.tanh(r*t)+1)/2   
    return (lamb)

def forcing_bump(x, a, b, c, d, bump):
    """
    Localised state coupling from upstream to downstream.

    Parameters
    ----------
    x : float64
        State variable of upstream system.
    a : float64
        Initial level of forcing.
    b : float64
        Amplitude of forcing.
    c : float64
        Strength of localisation.
    d : float64
        Offset coupling parameter.

    Returns
    -------
    loc : float64
        Localised state downstream overshoot forcing profile.

    """       
    # Define conditions
    conditions = [np.abs(x-d)>=1/np.abs(c), np.abs(x-d)<1/np.abs(c)]  
    
    # Define functions for each condition
    functions = [0, lambda x: a + b*bump(c*(x-d))]  
    
    # Apply piecewise function
    loc = np.piecewise(x, conditions, functions)

    
    return (loc)

def forcing_lin(x, a, b):
    """
    Linear coupling from upstream to downstream.

    Parameters
    ----------
    x : float64
        State variable of upstream system.
    a : float64
        Initial level of forcing.
    b : float64
        Rate of linear increase.

    Returns
    -------
    lin : float64
        Linear coupling for downstream forcing profile.

    """   
    lin = a + b*(x+np.sqrt(3))
    
    return (lin)

def bump(x):
    """
    Bump function.

    Parameters
    ----------
    x : float64
        Input variable.

    Returns
    -------
    bump_func : float64
        Bump function.

    """ 
    bump_func = np.exp((x**2)/((x**2)-1))
    
    return (bump_func)

fontsize = 14
rc('font', **{'size' : fontsize})
rc('text', usetex=True)

# Switch to determine if coupling is linear or via bump function
LINEAR = True

# Time parameters
tstart = -55                        # Start time
tend = 50                           # End time
dt = 0.005                          # Spacing between time intervals
n = int((tend - tstart)/dt)         # Number of time intervals
t = np.linspace(tstart, tend, n+1)  # Time values

# System parameter
epsilon = 0.05      # Timescale separation

# Upstream forcing parameters
lamb_min = 0        # Start level of upstream forcing
lamb_max = 4        # End level of upstream forcing 
r = 0.05            # Rate parameter of upstream forcing

# Downstream forcing parameters
a = 0               # Start level of downstream forcing
c = 2               # Inv. prop. to overshoot period of downstream forcing
d = 0.5             # Offset for coupling of downstream forcing during tipping of upstream 

# Number of sample profiles to plot
nr = 11

# Select nr evenly spaced values for coupling strength
if LINEAR:
    b = np.linspace(0,1,nr)     # Rate of linear increase in linear coupling
else:
    b = np.linspace(0,4,nr)     # Amplitude for bump function


# Initialise variables
x_det = np.zeros(n+1)    
y_det = np.zeros((n+1,nr))    
speed = np.zeros((n+1,nr))      

# Initialise start points for variables
x_det[0] = -np.sqrt(3)
y_det[0,:] = -np.sqrt(3)

# Initialise figure
fig,ax = plt.subplots(1,3,figsize=(12.8,4))

ax[0].set_xlabel(r'$\Lambda(rt)$')

if LINEAR:
    ax[0].set_xlim(1.8,3)
    ax[0].set_ylabel(r'$M_1(x(t))$')
else:
    ax[0].set_xlim(2.32,2.355)
    ax[0].set_ylabel(r'$M_2(x(t))$')

ax[0].set_ylim(0,4)

ax[1].plot([0,1],[0,1],'k--')

ax[1].set_xlabel('False positive rate')
ax[1].set_ylabel('True positive rate')

ax[1].set_xlim(0,1)
ax[1].set_ylim(0,1)
                
sns.despine()

ax[0].plot([2,2],[0,4],'k--',alpha=0.5,zorder=0)
ax[0].plot([0,4],[2,2],'k--',alpha=0.5,zorder=0)

# Use Euler method to calculate upstream trajectory 
for i in range(n):
    x_det[i+1] = x_det[i] + dt*f(x_det[i], forcing_ramp(t[i], lamb_min, lamb_max, r))

# Loop over all realisations
for j in range(nr):    
    
    if LINEAR:
        # Use Euler method to calculate downstream trajectories
        for i in range(n):
            y_det[i+1,j] = y_det[i,j] + dt*f(y_det[i,j], forcing_lin(x_det[i], a, b[j]))/epsilon    
            speed[i+1,j] = np.abs(forcing_lin(x_det[i+1], a, b[j])-forcing_lin(x_det[i], a, b[j]))  # Calculate derivative of coupling
        
        # Plot sanple profiles in plane of downstream forcing vs upstream forcing
        # - add red colour if derivative of coupling is above a specified threshold 
        ax[0].plot(forcing_ramp(t, lamb_min, lamb_max, r),forcing_lin(x_det, a, b[j]),'k',zorder=1)
        ax[0].plot(forcing_ramp(t[speed[:,j]>1e-3], lamb_min, lamb_max, r),forcing_lin(x_det[speed[:,j]>1e-3], a, b[j]),'r',zorder=2)
        
        # Identify point of tipping and mark with blue circle
        if np.max(y_det[:,j])>0:
            idx = np.argmin(np.abs(y_det[:,j]))
            ax[0].plot(forcing_ramp(t[idx], lamb_min, lamb_max, r),forcing_lin(x_det[idx], a, b[j]),marker='o',mfc='none', mec='b',ms=8,zorder=3)
 
    else:   
        # Use Euler method to calculate downstream trajectories
        for i in range(n):
            y_det[i+1,j] = y_det[i,j] + dt*f(y_det[i,j], forcing_bump(x_det[i], a, b[j], c, d, bump))/epsilon    
            speed[i+1,j] = np.abs(forcing_bump(x_det[i+1], a, b[j], c, d, bump)-forcing_bump(x_det[i], a, b[j], c, d, bump))    # Calculate derivative of coupling
        
        # Plot sanple profiles in plane of downstream forcing vs upstream forcing
        # - add red colour if derivative of coupling is above a specified threshold
        ax[0].plot(forcing_ramp(t, lamb_min, lamb_max, r),forcing_bump(x_det, a, b[j], c, d, bump),'k',zorder=1)
        ax[0].plot(forcing_ramp(t[speed[:,j]>1e-3], lamb_min, lamb_max, r),forcing_bump(x_det[speed[:,j]>1e-3], a, b[j], c, d, bump),'r',zorder=2)
        
        # Identify point of tipping and mark with blue circle
        if np.max(y_det[:,j])>0:
            idx = np.argmin(np.abs(y_det[:,j]))
            ax[0].plot(forcing_ramp(t[idx], lamb_min, lamb_max, r),forcing_bump(x_det[idx], a, b[j], c, d, bump),marker='o',mfc='none', mec='b',ms=8,zorder=3)
        
 
    
       
# Read in saved EWS data
if LINEAR:
    mat_contents = sp.loadmat("Downstream_decay_rate2_wl20_lin_b_0_1_data.mat")
else:
    mat_contents = sp.loadmat("Downstream_decay_rate2_wl20_loc_bump_b_0_4_data.mat")

# Extract variables from dataset
t = mat_contents['t'][0]        # Time
y = mat_contents['y']           # Downstream system response trajectories
Decay2 = mat_contents['Decay2'] # Square of decay rate

# Time parameters
tstart = t[0]                   # Start time
dt = t[1] - t[0]                # Time step

# Parameters
N = 100                             # Number of cases of tipping and non tipping required in tipping window
N2 = len(y[0,:])                    # Number of Monte-Carlo simulations performed
wf = 20                             # Window length that linear fit is applied to
wf_pts = int(wf/dt)                 # Number of data points for linear fit
tf = np.linspace(0, wf, wf_pts+1)   # Array of points for linear fit

# Arrays for prediction and horizon times considered
tp = np.linspace(-2,5,36)
Delta = np.linspace(0.25,5,20)

# Initialise arrays for AUC and optimal threshold
AUC = np.zeros((len(tp),len(Delta)))
OptThr = np.zeros((len(tp),len(Delta)))

# Prediction and horizon times for sample ROC curves
tp_example = [1,2,3]
Delta_example = [3,3,3]

# Initialise colours for ROC curves 
colours = ['tab:orange','tab:blue','tab:red'] 

# Initialise counter
counter = 0

# Initial guess for linear fit coefficients using least squares
x0 = [1,1]

# Loop over all prediction and horizon times
for k in range(len(tp)):
    for l in range(len(Delta)):

        # Loop over all Monte-Carlo simulations
        for j in range(N2):
            
            # Identify realisations that undergo downstream tipping within window [tp,tp+Delta]
            idx_y1 = y[int((tp[k]-tstart)/dt),:j]<=0 
            idx_y2 = y[int((tp[k]+Delta[l]-tstart)/dt),:j]>0
            idx_y = np.logical_and(idx_y1, idx_y2)
            
            # If have N cases of tipping in window and not having tipped after
            # window, break for loop and proceed to ROC/AUC calculation
            if (np.sum(idx_y[:j])>=N) and (np.sum(~idx_y2[:j])>=N):
                break
        
        # If not sufficient number of cases assing NaN for AUC and optimal threshold
        if j == N2-1:
            AUC[k,l] = np.nan        
            OptThr[k,l] = np.nan
            
        else:
            # Extract square of decay rate for tipping and non-tipping cases
            Decay2_tip = Decay2[:,:j][:,idx_y[:j]]
            Decay2_notip = Decay2[:,:j][:,~idx_y2[:j]]#[:,~idx_x3[:j]]#
            
            # Initialise arrays for scoring classifier
            Scor_clas_tip = np.zeros(N)
            Scor_clas_notip = np.zeros(N)            
            
            for j in range(N):
                # Obtain coefficients for linear fit to square of decay rate using
                # least squares for each tipping and non-tipping identified simulation
                res_lsq_tip = least_squares(fun, x0, args=(tf,Decay2_tip[int((tp[k]-tstart)/dt-wf_pts):int((tp[k]-tstart)/dt+1),j]))
                res_lsq_notip = least_squares(fun, x0, args=(tf,Decay2_notip[int((tp[k]-tstart)/dt-wf_pts):int((tp[k]-tstart)/dt+1),j]))
                
                # Calculate scoring classifier at end of window for each tipping and non-tipping identified simulation
                Scor_clas_tip[j] = res_lsq_tip.x[0]+res_lsq_tip.x[1]*(wf+Delta[l])
                Scor_clas_notip[j] = res_lsq_notip.x[0]+res_lsq_notip.x[1]*(wf+Delta[l])
            
            # Array of thresholds to loop over and compare with scoring classifier to make prediction of tipping or not
            Thresholds = np.linspace(np.min((Scor_clas_tip,Scor_clas_notip))-1,np.max((Scor_clas_tip,Scor_clas_notip))+1,100001)
                
            # Initialise arrays for false positive and true positive rates for square of decay rate
            FPR = np.zeros(len(Thresholds))
            TPR = np.zeros(len(Thresholds))
            
            
            # Loop over different thresholds and calculate false positive and true positive 
            # rates for square of decay rate (comparing to score classifier) 
            for i in range(len(Thresholds)):
                FPR[i] = np.sum(Scor_clas_notip<Thresholds[i])/N
                TPR[i] = np.sum(Scor_clas_tip<Thresholds[i])/N
            
            # Integrate area under ROC to get AUC   
            AUC[k,l] = integrate(FPR, TPR)
            
            # Identify optimal threshold as threshold that gives closest value to (FPR,TPR) = (0,1)
            OptThr[k,l] = Thresholds[np.argmin(np.sqrt(FPR**2+(TPR-1)**2))]
            
            # If tp and Delta correspond to one of the examples plot the corresponding ROC curve
            if np.nanmin(np.abs(tp[k]-tp_example) + np.abs(Delta[l] - Delta_example)) == 0:
                ax[1].plot(FPR,TPR,c=colours[counter])
                counter = counter+1


### Plotting AUC colour plot ### ###
tp_edges = np.linspace(tp[0]-(tp[1]-tp[0])/2,tp[-1]+(tp[1]-tp[0])/2,len(tp)+1)
Delta_edges = np.linspace(Delta[0]-(Delta[1]-Delta[0])/2,Delta[-1]+(Delta[1]-Delta[0])/2,len(Delta)+1)

[TP,DELTA] = np.meshgrid(tp_edges,Delta_edges)

vr = np.concatenate((np.concatenate(([0.5],np.linspace(0.55,0.95,5))),[1]))
cmap_name2 = 'viridis'
cmap2 = plt.cm.get_cmap(cmap_name2,len(vr)+1)
cmap2 = truncate_colormap(cmap2, minval=0.2, maxval=1)
norm2 = colors.BoundaryNorm(vr, cmap2.N)

im = ax[2].pcolor(TP,DELTA,AUC.T,cmap=cmap2,norm=norm2)
ax[2].pcolor(TP,DELTA, np.ma.masked_less(OptThr.T, 10), hatch='xx', alpha=0.)
ax[2].pcolor(TP,DELTA, np.ma.masked_outside(OptThr.T, 5, 10), hatch='**', alpha=0.)
ax[2].pcolor(TP,DELTA, np.ma.masked_outside(OptThr.T, 0, 5), hatch='..', alpha=0.)
ax[2].set_xlabel('$t_p$')
ax[2].set_ylabel(r'$\Delta$')
ax[2].set_xlim(-2,5)
ax[2].set_ylim(0,5)

for i in range(len(tp_example)):
    ax[2].plot(tp_example[i],Delta_example[i],color=colours[i],marker='*',ms=14,mec='w')

fig.tight_layout()
fig.subplots_adjust(top=0.945,bottom=0.15,left=0.05,right=0.91,hspace=0.2,wspace=0.3)
cbar_ax = fig.add_axes([0.915, 0.15, 0.015, 0.795])
cbar = fig.colorbar(im, spacing='proportional', ticks=np.linspace(0.5,1,6), cax=cbar_ax)
cbar.ax.set_ylabel('Area under ROC')