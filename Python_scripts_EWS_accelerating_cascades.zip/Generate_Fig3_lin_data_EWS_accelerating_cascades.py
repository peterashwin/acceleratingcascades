# -*- coding: utf-8 -*-
"""
Created on Wed May  7 14:14:52 2025

@author: Paul

Script to generate N = 1,000 Monte-Carlo simulations with a random choice between
two possible values for final level in ramp forcing, and calculate the square of 
the decay rate. Data created from this script is used for creation of upper
row of panels in Figure 3 in 'Early warning skill, extrapolation and tipping for
accelerating cascades'
"""

import numpy as np
import scipy
from scipy import stats

def f(x, forcing):
    """
    Generic double fold bifurcation model used for both upstream and downstream
    systems.

    Parameters
    ----------
    x : float64
        State variable for upstream or downstream system.
    forcing : float64
        External forcing to drive the system.

    Returns
    -------
    f : float64
        RHS of ODE.

    """  
    f = 3*x - x**3 + forcing    
    return (f)

def forcing_ramp(t, lamb_min, lamb_max, r):
    """
    Tanh ramp forcing for upstream system.

    Parameters
    ----------
    t : float64
        Time
    lamb_min : float64
        Initial level of forcing.
    lamb_max : float64
        Final level of forcing.
    r : float64
        Rate parameter of ramp.

    Returns
    -------
    lamb : float64
        Upstream ramp forcing profile.

    """
    lamb = lamb_min + (lamb_max-lamb_min)*(np.tanh(r*t)+1)/2   
    return (lamb)


def calculate_EWS(x,x_det):
    """
    Calculation of generic early warning signals (lag-1 autocorrelation and 
    variance).

    Parameters
    ----------
    x : Array of float64
        An array of the state variable for the length of the sliding window.
    x_det : Array of float64
        An array of the determinstic state variable for the length of the
        sliding window.

    Returns
    -------
    Aut : float64
          Lag-1 autocorrelation.
    Var : float64
          Variance.

    """
    window = x-x_det        # Detrend window using deterministic solution
    
    # Calculate EWS
    Var = np.var(window)
    Aut,_ = stats.pearsonr(window[:-1],window[1:])
    
    return(Aut, Var)


# Initialise seed
np.random.seed(1)

# Time parameters
tstart = -55                        # Start time
tend = 50                           # End time
dt = 0.005                          # Spacing between time intervals
n = int((tend - tstart)/dt)         # Number of time intervals
t = np.linspace(tstart, tend, n+1)  # Time values

# Number of realisations
N = 1000

# Forcing parameters
lamb_min = 0                                # Start level of upstream forcing
lamb_max = np.random.choice([1,3],size=N)   # Make N random choices {1,3} for final level in ramp forcing
r = 0.05                                    # Ramp steepness of upstream forcing

# Noise intensity
sigma1 = 0.1

# Initialise variables 
x = np.zeros((n+1,N))    
x_det = np.zeros((n+1,N))       

# Initialise start points for variables
x[0,:] = -np.sqrt(3)
x_det[0,:] = -np.sqrt(3)

# EWS parameters
wl = 20                             # Time length of sliding window
burn = 5                            # Burn time length to remove any transient behaviour
wl_pts = int(wl/dt)                 # Number of points in sliding window

# Initialise EWS
Aut = np.zeros((n+1,N))

# Loop over all realisations
for j in range(N):
    
    # Noise realisations for upstream system   
    randomv_x = np.random.normal(0, 1, n)
    
    # Calculate stochastic and deterministic trajectories using Euler method
    for i in range(n):
        x[i+1,j] = x[i,j] + dt*f(x[i,j], forcing_ramp(t[i], lamb_min, lamb_max[j], r)) + np.sqrt(dt)*sigma1*randomv_x[i]
        x_det[i+1,j] = x_det[i,j] + dt*f(x_det[i,j], forcing_ramp(t[i], lamb_min, lamb_max[j], r))

        # Calculate EWS
        if i+2>=wl_pts:
            Aut[i+1,j], _ = calculate_EWS(x[i+2-wl_pts:i+2,j], x_det[i+2-wl_pts:i+2,j])
        else:
            Aut[i,j] = np.nan

# Calculate square of the decay rate
Decay2 = (-np.log(Aut)/dt)**2

# Save data to file
scipy.io.savemat('Upstream_decay_rate2_wl20_lambmax_1_3_bimodal_data.mat', {'x':x, 't':t, 'Decay2':Decay2})