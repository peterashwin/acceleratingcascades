# -*- coding: utf-8 -*-
"""
Created on Wed May  7 13:15:58 2025

@author: Paul Ritchie

Script to generate N = 1,000 Monte-Carlo simulations with a random choice between
two possible values for the peak in bump forcing, and calculate the square of 
the decay rate. Data created from this script is used for creation of lower
row of panels in Figure 3 in 'Early warning skill, extrapolation and tipping for
accelerating cascades'
"""

import numpy as np
import scipy
from scipy import stats

def bump(x):
    """
    Bump function.

    Parameters
    ----------
    x : float64
        Input variable.

    Returns
    -------
    bump_func : float64
        Bump function.

    """ 
    bump_func = np.exp((x**2)/((x**2)-1))
    
    return (bump_func)

def f(x, forcing):
    """
    Generic double fold bifurcation model used for both upstream and downstream
    systems.

    Parameters
    ----------
    x : float64
        State variable for upstream or downstream system.
    forcing : float64
        External forcing to drive the system.

    Returns
    -------
    f : float64
        RHS of ODE.

    """  
    f = 3*x - x**3 + forcing    
    return (f)


def forcing_bump(x, a, b, c, d, bump):
    """
    Localised state coupling from upstream to downstream.

    Parameters
    ----------
    x : float64
        State variable of upstream system.
    a : float64
        Initial level of forcing.
    b : float64
        Amplitude of forcing.
    c : float64
        Strength of localisation.
    d : float64
        Offset coupling parameter.

    Returns
    -------
    loc : float64
        Localised state downstream overshoot forcing profile.

    """       
    # Define conditions
    conditions = [np.abs(x-d)>=1/np.abs(c), np.abs(x-d)<1/np.abs(c)]  
    
    # Define functions for each condition
    functions = [0, lambda x: a + b*bump(c*(x-d))]  
    
    # Apply piecewise function
    loc = np.piecewise(x, conditions, functions)

    
    return (loc)


def calculate_EWS(x,x_det):
    """
    Calculation of generic early warning signals (lag-1 autocorrelation and 
    variance).

    Parameters
    ----------
    x : Array of float64
        An array of the state variable for the length of the sliding window.
    x_det : Array of float64
        An array of the determinstic state variable for the length of the
        sliding window.

    Returns
    -------
    Aut : float64
          Lag-1 autocorrelation.
    Var : float64
          Variance.

    """
    window = x-x_det        # Detrend window using deterministic solution
    
    # Calculate EWS
    Var = np.var(window)
    Aut,_ = stats.pearsonr(window[:-1],window[1:])
    
    return(Aut, Var)


# Initialise seed
np.random.seed(1)

# Time parameters
tstart = -55                        # Start time
tend = 50                           # End time
dt = 0.005                          # Spacing between time intervals
n = int((tend - tstart)/dt)         # Number of time intervals
t = np.linspace(tstart, tend, n+1)  # Time values

# Number of realisations
N = 1000

# Forcing parameters
a = 0                               # Initial level of forcing
c = 0.05                            # Strength of localisation
d = 0                               # Offset coupling parameter
b = np.random.choice([1.5,2.5],size=N)      # Make N random choices {1.5,2.5} for amplitude of bump forcing 

# Noise intensity
sigma1 = 0.1

# Initialise variables 
x = np.zeros((n+1,N))    
x_det = np.zeros((n+1,N))       

# Initialise start points for variables
x[0,:] = -np.sqrt(3)
x_det[0,:] = -np.sqrt(3)

# EWS parameters
wl = 20                             # Time length of sliding window
burn = 5                            # Burn time length to remove any transient behaviour
wl_pts = int(wl/dt)                 # Number of points in sliding window

# Initialise EWS
Aut = np.zeros((n+1,N))

# Loop over all realisations
for j in range(N):
    
    # Noise realisations for upstream system   
    randomv_x = np.random.normal(0, 1, n)
    
    # Calculate stochastic and deterministic trajectories using Euler method
    for i in range(n):
        x[i+1,j] = x[i,j] + dt*f(x[i,j], forcing_bump(t[i], a, b[j], c, d, bump)) + np.sqrt(dt)*sigma1*randomv_x[i]
        x_det[i+1,j] = x_det[i,j] + dt*f(x_det[i,j], forcing_bump(t[i], a, b[j], c, d, bump))
        
        # Calculate EWS
        if i+2>=wl_pts:
            Aut[i+1,j], _ = calculate_EWS(x[i+2-wl_pts:i+2,j], x_det[i+2-wl_pts:i+2,j])
        else:
            Aut[i,j] = np.nan

# Calculate square of the decay rate
Decay2 = (-np.log(Aut)/dt)**2

# Save data to file
scipy.io.savemat('Upstream_bump_decay_rate2_wl20_b_1p5_2p5_bimodal_data.mat', {'x':x, 't':t, 'Decay2':Decay2})