# -*- coding: utf-8 -*-
"""
Created on Wed May  7 09:47:39 2025

@author: Paul Ritchie

Script to plot ROC curves and AUC colour plot - Figure 3 in 'Early warning skill,
extrapolation and tipping for accelerating cascades'.
"""

import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.optimize import least_squares
import scipy.io as sp
from matplotlib import rc
import matplotlib.colors as colors

def truncate_colormap(cmap, minval=0.0, maxval=1.0, n=100):
    new_cmap = colors.LinearSegmentedColormap.from_list(
        'trunc({n},{a:.2f},{b:.2f})'.format(n=cmap.name, a=minval, b=maxval),
        cmap(np.linspace(minval, maxval, n)))
    return new_cmap

def fun(x,t,decay_rate):
    """
    Function for applying a linear fit to the square of the decay rate using
    least squares.
    
    Parameters
    ----------
    x : Array of float64
        Coefficients of linear fit
    t : Array of float64
        Dummy variable
    decay_rate : Array of float64
        Square of decay rate that linear fit is applied to

    Returns
    -------
    residual : Array of float64
          Residual between linear fit and square of decay rate

    """
    
    residual = np.array(x[0]+x[1]*t-decay_rate)
    
    return residual

def integrate(x, y):
    """
    Apply trapezoidal rule to integrate y with respect to x    
    Parameters
    ----------
    x : Array of float64
    y : Array of float64

    Returns
    -------
    sm : float64
          Integral of y with respect to x

    """
    sm = 0
    for i in range(1, len(x)):
        # Step spacing
        h = x[i] - x[i-1]
        # Trapezoidal rule
        sm += h * (y[i-1] + y[i]) / 2
 
    return sm

fontsize = 14
rc('font', **{'size' : fontsize})
rc('text', usetex=True)

# Switch to determine if using monotonic ramp forcing or non-monotonic bump forcing
MONOTONIC = False

# Read in saved EWS data
if MONOTONIC:
    mat_contents = sp.loadmat("Upstream_decay_rate2_wl20_lambmax_1_3_bimodal_data.mat")
else:
    mat_contents = sp.loadmat("Upstream_bump_decay_rate2_wl20_b_1p5_2p5_bimodal_data.mat")

# Extract variables from dataset
t = mat_contents['t'][0]        # Time
x = mat_contents['x']           # System response trajectories
Decay2 = mat_contents['Decay2'] # Square of decay rate

# Time parameters
tstart = t[0]                   # Start time
dt = t[1] - t[0]                # Time step

# Parameters
N = 100                         # Number of cases of tipping and non tipping required in tipping window
N2 = len(x[0,:])                # Number of Monte-Carlo simulations performed

Delta = np.linspace(1,20,20)    # Array of time horizons considered

if MONOTONIC:
    tp = np.linspace(-10,15,26) # Array of prediction times considered
    wf = 20                     # Window length that linear fit is applied to
    tp_example = [0,10,10]      # Prediction times for sample ROC curves
    Delta_example = [15,5,15]   # Horizon times for sample ROC curves
else:
    tp = np.linspace(-20,5,26)  # Array of prediction times considered
    wf = 10                     # Window length that linear fit is applied to
    tp_example = [-14,-10,-6]   # Prediction times for sample ROC curves
    Delta_example = [10,10,10]  # Horizon times for sample ROC curves

wf_pts = int(wf/dt)                 # Number of data points for linear fit
tf = np.linspace(0, wf, wf_pts+1)   # Array of points for linear fit

# Initialise arrays for AUC and optimal threshold
AUC = np.zeros((len(tp),len(Delta)))
OptThr = np.zeros((len(tp),len(Delta)))

# Initialise figure
fig,ax = plt.subplots(1,2,figsize=(12.8,4.8))

ax[0].plot([0,1],[0,1],'k--')

ax[0].set_xlabel('False positive rate')
ax[0].set_ylabel('True positive rate')

ax[0].set_xlim(0,1)
ax[0].set_ylim(0,1)
                
sns.despine()

# Initialise colours for ROC curves 
colours = ['tab:orange','tab:blue','tab:red'] 

# Initialise counter
counter = 0

# Initial guess for linear fit coefficients using least squares
x0 = [1,1]

# Loop over all prediction and horizon times
for k in range(len(tp)):
    for l in range(len(Delta)):

        # Loop over all Monte-Carlo simulations
        for j in range(N2):
            
            # Identify realisations that undergo tipping within window [tp,tp+Delta]
            idx_x1 = x[int((tp[k]-tstart)/dt),:j]<=0 
            idx_x2 = x[int((tp[k]+Delta[l]-tstart)/dt),:j]>0
            idx_x = np.logical_and(idx_x1, idx_x2)
            
            # If have N cases of tipping in window and not having tipped after
            # window, break for loop and proceed to ROC/AUC calculation
            if (np.sum(idx_x[:j])>=N) and (np.sum(~idx_x2[:j])>=N):
                break
        
        # If not sufficient number of cases assing NaN for AUC and optimal threshold
        if j == N2-1:
            AUC[k,l] = np.nan        
            OptThr[k,l] = np.nan
            
        else:
            # Extract square of decay rate for tipping and non-tipping cases 
            Decay2_tip = Decay2[:,:j][:,idx_x[:j]]
            Decay2_notip = Decay2[:,:j][:,~idx_x2[:j]]            
            
            # Initialise arrays for scoring classifier
            Scor_clas_tip = np.zeros(N)
            Scor_clas_notip = np.zeros(N)           
            
            # Loop over each identified simulation of tipping and non-tipping
            for j in range(N):
                # Obtain coefficients for linear fit to square of decay rate using
                # least squares for each tipping and non-tipping identified simulation 
                res_lsq_tip = least_squares(fun, x0, args=(tf,Decay2_tip[int((tp[k]-tstart)/dt-wf_pts):int((tp[k]-tstart)/dt+1),j]))
                res_lsq_notip = least_squares(fun, x0, args=(tf,Decay2_notip[int((tp[k]-tstart)/dt-wf_pts):int((tp[k]-tstart)/dt+1),j]))
                
                # Calculate scoring classifier at end of window for each tipping and non-tipping identified simulation
                Scor_clas_tip[j] = res_lsq_tip.x[0]+res_lsq_tip.x[1]*(wf+Delta[l])
                Scor_clas_notip[j] = res_lsq_notip.x[0]+res_lsq_notip.x[1]*(wf+Delta[l])
            
            # Array of thresholds to loop over and compare with scoring classifier to make prediction of tipping or not
            Thresholds = np.linspace(np.min((Scor_clas_tip,Scor_clas_notip))-1,np.max((Scor_clas_tip,Scor_clas_notip))+1,100001)
                
            # Initialise arrays for false positive and true positive rates for square of decay rate 
            FPR = np.zeros(len(Thresholds))
            TPR = np.zeros(len(Thresholds))            
            
            # Loop over different thresholds and calculate false positive and true positive 
            # rates for square of decay rate (comparing to score classifier) 
            for i in range(len(Thresholds)):
                FPR[i] = np.sum(Scor_clas_notip<Thresholds[i])/N
                TPR[i] = np.sum(Scor_clas_tip<Thresholds[i])/N
            
            # Integrate area under ROC to get AUC   
            AUC[k,l] = integrate(FPR, TPR)
            
            # Identify optimal threshold as threshold that gives closest value to (FPR,TPR) = (0,1)
            OptThr[k,l] = Thresholds[np.argmin(np.sqrt(FPR**2+(TPR-1)**2))]
            
            # If tp and Delta correspond to one of the examples plot the corresponding ROC curve
            if np.nanmin(np.abs(tp[k]-tp_example) + np.abs(Delta[l] - Delta_example)) == 0:
                ax[0].plot(FPR,TPR,c=colours[counter])
                counter = counter+1


### Plotting AUC colour plot ###
tp_edges = np.linspace(tp[0]-(tp[1]-tp[0])/2,tp[-1]+(tp[1]-tp[0])/2,len(tp)+1)
Delta_edges = np.linspace(Delta[0]-(Delta[1]-Delta[0])/2,Delta[-1]+(Delta[1]-Delta[0])/2,len(Delta)+1)

[TP,DELTA] = np.meshgrid(tp_edges,Delta_edges)

vr = np.concatenate((np.concatenate(([0.5],np.linspace(0.55,0.95,5))),[1]))
cmap_name2 = 'viridis'
cmap2 = plt.cm.get_cmap(cmap_name2,len(vr)+1)
cmap2 = truncate_colormap(cmap2, minval=0.2, maxval=1)
norm2 = colors.BoundaryNorm(vr, cmap2.N)

im = ax[1].pcolor(TP,DELTA,AUC.T,cmap=cmap2,norm=norm2)
ax[1].pcolor(TP,DELTA, np.ma.masked_less(np.abs(OptThr.T), 10), hatch='xx', alpha=0.)
ax[1].pcolor(TP,DELTA, np.ma.masked_outside(np.abs(OptThr.T), 5, 10), hatch='**', alpha=0.)
ax[1].pcolor(TP,DELTA, np.ma.masked_outside(np.abs(OptThr.T), 2, 5), hatch='..', alpha=0.)
ax[1].set_xlabel('$t_p$')
ax[1].set_ylabel(r'$\Delta$')
ax[1].set_xlim(tp[0],tp[-1])
ax[1].set_ylim(0,20)

for i in range(len(tp_example)):
    ax[1].plot(tp_example[i],Delta_example[i],color=colours[i],marker='*',ms=14,mec='w')

fig.tight_layout()
fig.subplots_adjust(right=0.9,wspace=0.25)
cbar_ax = fig.add_axes([0.915, 0.15, 0.015, 0.795])
cbar = fig.colorbar(im, spacing='proportional', ticks=np.linspace(0.5,1,6), cax=cbar_ax)
cbar.ax.set_ylabel('Area under ROC')